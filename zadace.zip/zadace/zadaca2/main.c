#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>

#define SHM_KEY 0x9876

// Struktura koja sadrži zajedničke varijable iz tvog zadatka
struct Dekker {
    int ZASTAVICA[2]; // ZASTAVICA[0..1]
    int PRAVO;        // PRAVO
};

int shmid = -1;
struct Dekker *zajednicka_memorija = NULL;

// Prekidna rutina za Ctrl+C koja briše zajedničku memoriju
void cleanup_handler(int sig) {
    printf("\n[PREKID] Hvatanje Ctrl+C. Brisanje resursa iz sustava...\n");
    if (zajednicka_memorija != NULL && zajednicka_memorija != (void *)-1) {
        shmdt(zajednicka_memorija);
    }
    if (shmid != -1) {
        shmctl(shmid, IPC_RMID, NULL);
        printf("[-] Zajednička memorija uspješno uklonjena.\n");
    }
    exit(0);
}

// --- FUNKCIJA: UĐI U KRITIČNI ODSJEČAK ---
void udji_u_kriticni_odsjecak(int i, int j) {
    zajednicka_memorija->ZASTAVICA[i] = 1; // p1 želi ući
    
    // dok je ZASTAVICA[j] <> 0 čini
    while (zajednicka_memorija->ZASTAVICA[j] != 0) { 
        
        // ako je PRAVO = j onda
        if (zajednicka_memorija->PRAVO == j) { 
            zajednicka_memorija->ZASTAVICA[i] = 0; // p1 odustaje
            
            // dok je PRAVO = j čini ništa
            while (zajednicka_memorija->PRAVO == j) {
                // ništa (prazna petlja, dodajemo usleep radi štednje procesora)
                usleep(100); 
            }
            
            zajednicka_memorija->ZASTAVICA[i] = 1; // pa javi da želi ući
        }
    }
}

// --- FUNKCIJA: IZAĐI IZ KRITIČNOG ODSJEČKA ---
void izadji_iz_kriticnog_odsjecka(int i, int j) {
    zajednicka_memorija->PRAVO = j;        // prednost dajemo p2
    zajednicka_memorija->ZASTAVICA[i] = 0; // izlaz
}

// Glavna logika procesa/dretve
void proc(int i) {
    int j = 1 - i; // Ako je i=0 onda je j=1, ako je i=1 onda je j=0

    // za k = 1 do 5 čini
    for (int k = 1; k <= 5; k++) {
        
        udji_u_kriticni_odsjecak(i, j);

        // --- KRITIČNI ODSJEČAK ---
        // za m = 1 do 5 čini ispiši (i, k, m)
        for (int m = 1; m <= 5; m++) {
            printf("Proces %d: (i=%d, k=%d, m=%d)\n", i, i, k, m);
            fflush(stdout); 
            usleep(50000); // Kratka pauza da ispis na ekranu ne "proleti" prebrzo
        }
        // -------------------------

        izadji_iz_kriticnog_odsjecka(i, j);
        
        usleep(10000); // Pauza izvan kritičnog odsječka
    }
}

int main() {
    // Postavljanje prekidne rutine (Ctrl+C)
    signal(SIGINT, cleanup_handler);

    // Stvaranje zajedničke memorije
    shmid = shmget(SHM_KEY, sizeof(struct Dekker), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("Greška pri shmget");
        exit(1);
    }

    // Spajanje na zajedničku memoriju
    zajednicka_memorija = (struct Dekker *)shmat(shmid, NULL, 0);
    if (zajednicka_memorija == (void *)-1) {
        perror("Greška pri shmat");
        shmctl(shmid, IPC_RMID, NULL);
        exit(1);
    }

    // Inicijalizacija zajedničkih varijabli s početka tvog pseudokoda
    zajednicka_memorija->ZASTAVICA[0] = 0;
    zajednicka_memorija->ZASTAVICA[1] = 0;
    zajednicka_memorija->PRAVO = 0; // Početna prednost procesu 0

    printf("[START] Pokrećem paralelne procese...\n");

    // Stvaranje dva procesa pomoću fork()
    pid_t pid1 = fork();
    if (pid1 == 0) {
        proc(0); // Prvi proces (i=0)
        exit(0);
    }

    pid_t pid2 = fork();
    if (pid2 == 0) {
        proc(1); // Drugi proces (i=1)
        exit(0);
    }

    // Otac čeka oba procesa da završe
    wait(NULL);
    wait(NULL);

    // Redovno čišćenje na kraju programa
    printf("\n[KRAJ] Procesi su uspješno završili. Brišem resurse.\n");
    cleanup_handler(SIGINT);

    return 0;
}
